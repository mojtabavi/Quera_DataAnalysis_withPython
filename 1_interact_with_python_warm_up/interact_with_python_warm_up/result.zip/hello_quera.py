# coding: utf-8
def hello_quera():
    return "Hello Quera"
