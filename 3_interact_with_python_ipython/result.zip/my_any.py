# coding: utf-8
def my_any(x):
    for element in x:
        if (element):
            return True
        else:
            return False
